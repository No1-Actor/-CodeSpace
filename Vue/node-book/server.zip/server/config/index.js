// 数据库的配置
const config = {
    database: {
        DATABASE: 'note-book',
        USERNAME: 'root',
        PASSWORD: '123456',
        HOST: 'localhost',
        PORT: '3306'
    }
}

module.exports = config;